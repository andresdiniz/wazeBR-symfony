# Feature: Briefing Diário de Mobilidade

E-mail diário automático com dados de tráfego Waze + análise narrativa por IA (Gemini Flash),
enviado às 06h BRT para todos os parceiros cadastrados.

## Arquivos desta feature

```
src/
├── Command/
│   └── WazeDailyBriefingCommand.php      # orquestra tudo; um command por execução
├── Service/
│   ├── BriefingDataService.php           # queries SQL com CONVERT_TZ para BRT
│   ├── AiNarrativeService.php            # chamada ao Gemini Flash com retry/fallback
│   └── BriefingSchedulerService.php      # decide qual parceiro recebe IA hoje
├── DependencyInjection/
│   └── BriefingExtension.php             # lê briefing.yaml → parâmetros do container
config/
├── packages/
│   └── briefing.yaml                     # parceiros, estratégia, modelo Gemini
└── services_briefing_snippet.yaml        # wiring para colar em services.yaml
templates/
└── email/
    └── daily_briefing.html.twig          # e-mail HTML responsivo (inline CSS)
```

## Instalação

### 1. Variáveis de ambiente (`.env`)

```dotenv
# Gemini AI (Google AI Studio — gratuito: 1.500 req/dia)
GEMINI_API_KEY=AIzaSy...
GEMINI_MODEL=gemini-1.5-flash-latest

# URL base do TrafikHub (usado nos links do e-mail)
APP_URL=https://trafikhub.waze.com.br
```

Obter chave gratuita: https://aistudio.google.com/app/apikey

### 2. Copiar os arquivos

Copiar cada arquivo para o caminho correspondente no projeto wazeBR-symfony.

Em `config/services.yaml`, adicionar o conteúdo de `services_briefing_snippet.yaml`
dentro do bloco `services:`.

### 3. Registrar a Extension (opcional, mas recomendado)

Em `src/Kernel.php`:

```php
protected function build(ContainerBuilder $container): void
{
    parent::build($container);
    $container->registerExtension(new \App\DependencyInjection\BriefingExtension());
}
```

Depois carregar o YAML em `config/packages/briefing.yaml` — o Symfony faz isso
automaticamente se a Extension estiver registrada.

**Alternativa sem Extension:** copiar os parâmetros diretamente em `services.yaml`
conforme mostrado em `services_briefing_snippet.yaml`.

### 4. Crontab

Os dados do Waze chegam em **UTC**. O briefing é enviado às **06h BRT (09h UTC)**.

```cron
# Crontab do servidor (timezone UTC)
# Seg–Sex às 09h UTC = 06h BRT
0 9 * * 1-5 /usr/bin/php /var/www/html/bin/console waze:briefing:daily >> /var/log/waze_briefing.log 2>&1
```

Se o servidor estiver em `America/Sao_Paulo`:

```cron
0 6 * * 1-5 /usr/bin/php /var/www/html/bin/console waze:briefing:daily
```

## Uso manual

```bash
# Envia para todos os parceiros ativos (dados de ontem)
php bin/console waze:briefing:daily

# Testa um parceiro específico sem enviar e-mail
php bin/console waze:briefing:daily --cidade="Conselheiro Lafaiete" --dry-run

# Força data específica (útil para reenvio)
php bin/console waze:briefing:daily --data=2026-09-27

# Envia sem narrativa de IA (todos os parceiros, mais rápido)
php bin/console waze:briefing:daily --no-ai
```

## Fuso horário — importante

Todos os campos de data no banco estão em **UTC**.
As queries usam `CONVERT_TZ(campo, '+00:00', '-03:00')` para converter para BRT
**antes** de filtrar por data — então o "dia anterior" respeita corretamente a
meia-noite no horário de Brasília.

Exemplo: um jam registrado às 23:30 UTC do dia 27/09 = 20:30 BRT do dia 27/09.
Sem conversão, esse registro seria contado no dia 27/09 UTC mas pertence ao
**27/09 BRT** — que é o comportamento correto e esperado.

## Estratégias de IA (`strategy` no briefing.yaml)

| Estratégia | Comportamento                                               | Quando usar              |
|------------|-------------------------------------------------------------|--------------------------|
| `always`   | Todos os parceiros recebem IA todo dia                      | ≤10 parceiros (padrão)   |
| `rotate`   | 2 parceiros/dia nos dias úteis, todos no fim de semana      | 10–25 parceiros          |
| `weekly`   | Cada parceiro recebe IA 1x/semana no `ai_day` configurado  | >25 parceiros ou quota baixa |

O Gemini Flash gratuito suporta **1.500 req/dia** — suficiente para `always`
com até ~10 parceiros sem custo.

## Estrutura do e-mail

```
┌─────────────────────────────────────────────┐
│  WAZE · Dados de Parceiro          [logo]   │  ← header azul escuro
│  Briefing Diário — Conselheiro Lafaiete     │
├─────────────────────────────────────────────┤
│  ⚠ Interdições ativas (se houver)           │  ← fundo vermelho
├─────────────────────────────────────────────┤
│  KPIs: total jams | vel. média | atraso | interdicoes  │  ← 4 cards
│  Comparativo 7 dias                         │
├─────────────────────────────────────────────┤
│  Alertas: total | buracos | acidentes | fechamentos    │
├─────────────────────────────────────────────┤
│  Tabela: picos horários (em BRT)            │
│  Tabela: top ruas congestionadas            │
│  Tabela: buracos por rua                    │
├─────────────────────────────────────────────┤
│  ✦ Análise Gemini AI  (só se use_ai=true)  │  ← fundo azul claro
│  Parágrafo 1: resumo do dia                 │
│  Parágrafo 2: ponto de atenção              │
│  Parágrafo 3: recomendação à gestão         │
├─────────────────────────────────────────────┤
│  [Acessar Dashboard completo →]             │  ← CTA
├─────────────────────────────────────────────┤
│  TrafikHub · Waze Brasil  |  UTC-3          │  ← footer cinza
└─────────────────────────────────────────────┘
```

## Fallback gracioso

Se a API do Gemini falhar (rede, rate limit, quota esgotada):
- O `AiNarrativeService` retorna `null` após 2 tentativas com 3s de intervalo
- O `Command` continua normalmente e envia o e-mail **sem o bloco de IA**
- O erro é logado via `LoggerInterface` mas **não interrompe** o envio aos demais parceiros
- O destinatário recebe um e-mail completo com todos os dados, apenas sem os parágrafos narrativos
