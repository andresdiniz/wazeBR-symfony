/**
 * history.js — Módulo para a página de histórico de rota
 * Versão aprimorada com gráficos, mapa, heatmap e interações.
 */
(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    const dataEl = document.getElementById('js-data');
    if (!dataEl) {
      console.warn('[History] Elemento #js-data não encontrado. Abortando.');
      return;
    }

    const ds = dataEl.dataset;
    let raw, routeLine, jamLevel, fromName, toName, byJam, hourly, jamColors;

    try {
      raw = JSON.parse(ds.history);
      routeLine = JSON.parse(ds.line);
      jamLevel = parseInt(ds.jamLevel, 10) || 0;
      fromName = JSON.parse(ds.from);
      toName = JSON.parse(ds.to);
      byJam = JSON.parse(ds.byJam);
      hourly = JSON.parse(ds.hourly);
      jamColors = JSON.parse(ds.jamColors);
    } catch (e) {
      console.error('[History] Erro ao parsear dados JSON:', e);
      return;
    }

    const jamLabels = ['Livre', 'Lento', 'Moderado', 'Pesado', 'Muito Pesado', 'Parado'];
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
    const FMT = new Intl.DateTimeFormat('pt-BR', {
      timeZone: tz,
      day: '2-digit',
      month: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    });

    // ─── Gráfico de evolução temporal ─────────────────────────────
    const elHistory = document.getElementById('chart-history');
    if (elHistory && raw.length > 0) {
      const ordered = raw.slice().reverse();
      const labels = ordered.map(r => FMT.format(new Date(r.t)));
      const times = ordered.map(r => r.time !== null ? +(r.time / 60).toFixed(1) : null);
      const hists = ordered.map(r => r.hist !== null ? +(r.hist / 60).toFixed(1) : null);

      const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
      const gridColor = isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.06)';
      const textColor = isDark ? '#b0b0b0' : '#5a5a5a';

      new Chart(elHistory, {
        type: 'line',
        data: {
          labels: labels,
          datasets: [
            {
              label: 'Tempo atual (min)',
              data: times,
              borderColor: '#a12c7b',
              backgroundColor: 'oklch(0.5 0.2 330 / 0.10)',
              tension: 0.3,
              fill: true,
              pointRadius: 2,
              pointHoverRadius: 6,
              spanGaps: true,
              borderWidth: 2,
            },
            {
              label: 'Histórico (min)',
              data: hists,
              borderColor: '#437a22',
              backgroundColor: 'oklch(0.4 0.15 140 / 0.06)',
              borderDash: [5, 4],
              tension: 0.3,
              pointRadius: 2,
              pointHoverRadius: 6,
              spanGaps: true,
              borderWidth: 2,
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          interaction: { mode: 'index', intersect: false },
          plugins: {
            legend: {
              position: 'top',
              labels: {
                color: textColor,
                font: { size: 11, weight: '500' },
                boxWidth: 14,
                padding: 16,
              },
            },
            tooltip: {
              backgroundColor: isDark ? '#1a1a2e' : '#ffffff',
              titleColor: textColor,
              bodyColor: textColor,
              borderColor: isDark ? '#333' : '#ddd',
              borderWidth: 1,
              callbacks: {
                label: ctx => ctx.dataset.label + ': ' + (ctx.parsed.y !== null ? ctx.parsed.y.toFixed(1) + ' min' : '—'),
              },
            },
          },
          scales: {
            x: {
              ticks: { color: textColor, font: { size: 10 }, maxTicksLimit: 14, maxRotation: 45 },
              grid: { color: gridColor },
            },
            y: {
              beginAtZero: true,
              title: { display: true, text: 'minutos', color: textColor, font: { size: 10 } },
              ticks: { color: textColor, font: { size: 10 }, callback: v => v + ' min' },
              grid: { color: gridColor },
            },
          },
        },
      });
      console.log('[History] Gráfico de evolução temporal criado.');
    }

    // ─── Gráfico de distribuição (doughnut) ────────────────────────
    const elByJam = document.getElementById('chart-byjam');
    if (elByJam && byJam.length > 0) {
      new Chart(elByJam, {
        type: 'doughnut',
        data: {
          labels: jamLabels,
          datasets: [{ data: byJam, backgroundColor: jamColors, borderWidth: 0 }],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: 'right',
              labels: { boxWidth: 14, font: { size: 10, weight: '500' }, padding: 12 },
            },
          },
          cutout: '65%',
        },
      });
      console.log('[History] Gráfico de distribuição criado.');
    }

    // ─── Gráfico de perfil horário (barras) ────────────────────────
    const elHourly = document.getElementById('chart-hourly');
    if (elHourly && hourly.length > 0) {
      new Chart(elHourly, {
        type: 'bar',
        data: {
          labels: hourly.map(h => String(h.bucket).padStart(2, '0') + 'h'),
          datasets: [
            {
              label: 'Tempo atual (min)',
              data: hourly.map(h => h.avgTimeMin),
              backgroundColor: '#a12c7b',
              borderRadius: 4,
              borderSkipped: false,
            },
            {
              label: 'Histórico (min)',
              data: hourly.map(h => h.avgHistMin),
              backgroundColor: '#437a22',
              borderRadius: 4,
              borderSkipped: false,
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: 'top',
              labels: { font: { size: 10, weight: '500' }, boxWidth: 14 },
            },
          },
          scales: {
            y: {
              beginAtZero: true,
              title: { display: true, text: 'minutos', font: { size: 10 } },
              ticks: { font: { size: 9 } },
            },
            x: {
              ticks: { font: { size: 9 }, maxRotation: 45 },
            },
          },
        },
      });
      console.log('[History] Gráfico de perfil horário criado.');
    }

    // ─── Mapa Leaflet ──────────────────────────────────────────────
    const mapEl = document.getElementById('history-map');
    if (mapEl && routeLine && routeLine.length >= 2) {
      const map = L.map('history-map', { zoomControl: true, scrollWheelZoom: false });
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors',
        maxZoom: 19,
      }).addTo(map);

      const color = jamColors[jamLevel] || '#888';
      const latlngs = routeLine.map(p => [p.y, p.x]);
      const poly = L.polyline(latlngs, { color: color, weight: 5, opacity: 0.85 }).addTo(map);

      if (latlngs.length >= 2) {
        const mkPin = (letter, bg) => {
          const w = 30,
            h = 38;
          const svg =
            `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 30 38">
              <path d="M15 0 C6.716 0 0 6.716 0 15 C0 23.5 15 38 15 38 C15 38 30 23.5 30 15 C30 6.716 23.284 0 15 0 Z"
                    fill="${bg}" stroke="rgba(0,0,0,0.25)" stroke-width="1.5"/>
              <text x="15" y="20" text-anchor="middle" dominant-baseline="middle"
                    font-family="system-ui,sans-serif" font-size="14" font-weight="700" fill="#fff">${letter}</text>
            </svg>`;
          return L.divIcon({
            html: svg,
            className: '',
            iconSize: [w, h],
            iconAnchor: [w / 2, h],
            popupAnchor: [0, -h],
          });
        };

        L.marker(latlngs[0], { icon: mkPin('A', '#01696f') })
          .bindTooltip(fromName, { permanent: false, direction: 'top', className: 'custom-tooltip' })
          .addTo(map);

        L.marker(latlngs[latlngs.length - 1], { icon: mkPin('B', '#a12c7b') })
          .bindTooltip(toName, { permanent: false, direction: 'top', className: 'custom-tooltip' })
          .addTo(map);
      }

      map.fitBounds(poly.getBounds(), { padding: [30, 30] });
      console.log('[History] Mapa inicializado.');
    } else if (mapEl) {
      mapEl.innerHTML =
        '<div style="display:flex;align-items:center;justify-content:center;height:100%;color:var(--color-text-muted);font-size:var(--text-sm)">Geometria da rota não disponível</div>';
    }

    // ─── Formatação das datas no DOM ──────────────────────────────
    document.querySelectorAll('time[data-utc][data-fmt="datetime"]').forEach(el => {
      try {
        const d = new Date(el.dataset.utc);
        if (!isNaN(d.getTime())) {
          el.textContent = FMT.format(d);
        }
      } catch (e) {
        // mantém o conteúdo original
      }
    });

    // ─── Interação com o heatmap ──────────────────────────────────
    document.querySelectorAll('.heatmap-data:not(.is-empty)').forEach(cell => {
      cell.addEventListener('click', function () {
        this.style.transition = 'transform 0.1s ease';
        this.style.transform = 'scale(0.92)';
        setTimeout(() => {
          this.style.transform = 'scale(1)';
        }, 100);
      });
      cell.addEventListener('mouseenter', function () {
        this.style.zIndex = '3';
      });
      cell.addEventListener('mouseleave', function () {
        this.style.zIndex = '1';
      });
    });

    // ─── Tema escuro para o Leaflet ──────────────────────────────
    const observer = new MutationObserver(() => {
      // Não precisa fazer nada, os tiles OSM já são neutros
    });
    observer.observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });

    // ─── Animações de entrada ──────────────────────────────────────
    document.querySelectorAll('.kpi-card, .card').forEach(function (el, i) {
      el.style.opacity = '0';
      el.style.transform = 'translateY(15px)';
      setTimeout(function () {
        el.style.transition = 'opacity 0.4s ease, transform 0.4s ease';
        el.style.opacity = '1';
        el.style.transform = 'translateY(0)';
      }, 50 + i * 50);
    });

    console.log('[History] Página inicializada com sucesso.');
  });
})();
