// assets/admin/main.js – Lógica do painel admin

import L from 'leaflet';

document.addEventListener('DOMContentLoaded', () => {

    // ── Toggle de senha ──
    document.querySelectorAll('.toggle-pw').forEach(btn => {
        btn.addEventListener('click', () => {
            const input = document.getElementById(btn.dataset.target);
            if (input) {
                input.type = input.type === 'password' ? 'text' : 'password';
            }
        });
    });

    // ── Confirmação para ações destrutivas ──
    document.querySelectorAll('[data-confirm]').forEach(el => {
        el.addEventListener('click', (e) => {
            if (!confirm(el.dataset.confirm || 'Tem certeza?')) {
                e.preventDefault();
            }
        });
    });

    // ── Auto-slug (se houver campos name e slug) ──
    const nameInput = document.getElementById('name');
    const slugInput = document.getElementById('slug');
    if (nameInput && slugInput) {
        nameInput.addEventListener('input', () => {
            if (slugInput.dataset.edited) return;
            slugInput.value = nameInput.value
                .toLowerCase()
                .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
                .replace(/[^a-z0-9]+/g, '-')
                .replace(/^-+|-+$/g, '');
        });
        slugInput.addEventListener('input', () => { slugInput.dataset.edited = '1'; });
    }

    // ── Inicialização do mapa Leaflet (se houver) ──
    const mapContainer = document.getElementById('map');
    if (mapContainer) {
        const textarea = document.getElementById('bbox');
        let points = [], polyline = null, polygon = null, drawing = false;
        const btnDraw = document.getElementById('btnDraw');
        const btnClear = document.getElementById('btnClear');

        // Fallback se o L não estiver disponível (caso o import falhe)
        if (typeof L === 'undefined') {
            console.warn('Leaflet não carregado. Verifique o importmap.');
            return;
        }

        const map = L.map('map').setView([-15.8, -47.9], 5);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap contributors',
            maxZoom: 19
        }).addTo(map);

        function toWkt(pts) {
            if (pts.length < 3) return '';
            const coords = [...pts, pts[0]].map(p => p.lng.toFixed(10) + ' ' + p.lat.toFixed(10)).join(',');
            return 'POLYGON((' + coords + '))';
        }

        function renderPreview() {
            if (polyline) { map.removeLayer(polyline); polyline = null; }
            if (polygon)  { map.removeLayer(polygon);  polygon  = null; }
            if (points.length === 0) return;
            if (points.length < 3) {
                polyline = L.polyline(points, {color: '#1a56db', weight: 2, dashArray: '6 4'}).addTo(map);
            } else {
                polygon = L.polygon(points, {color: '#1a56db', weight: 2, fillColor: '#1a56db', fillOpacity: 0.12}).addTo(map);
            }
            textarea.value = toWkt(points);
        }

        function loadWkt(wkt) {
            if (!wkt) return;
            const m = wkt.match(/POLYGON\s*\(\((.+?)\)\)/i);
            if (!m) return;
            const pts = m[1].split(',').map(p => {
                const [lng, lat] = p.trim().split(/\s+/);
                return L.latLng(+lat, +lng);
            });
            if (pts.length > 1) pts.pop();
            points = pts;
            renderPreview();
            if (polygon) map.fitBounds(polygon.getBounds(), {padding: [24, 24]});
            else if (polyline) map.fitBounds(polyline.getBounds(), {padding: [24, 24]});
        }

        btnDraw.addEventListener('click', () => {
            drawing = !drawing;
            btnDraw.classList.toggle('drawing', drawing);
            btnDraw.innerHTML = drawing
                ? '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/></svg> Parar desenho'
                : '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="3 11 22 2 13 21 11 13 3 11"/></svg> Desenhar polígono';
            map.getContainer().style.cursor = drawing ? 'crosshair' : '';
        });

        btnClear.addEventListener('click', () => {
            points = [];
            renderPreview();
            textarea.value = '';
            drawing = false;
            btnDraw.classList.remove('drawing');
            btnDraw.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="3 11 22 2 13 21 11 13 3 11"/></svg> Desenhar polígono';
            map.getContainer().style.cursor = '';
        });

        map.on('click', e => {
            if (!drawing) return;
            points.push(e.latlng);
            renderPreview();
        });

        textarea.addEventListener('change', function() {
            points = [];
            loadWkt(this.value.trim());
        });

        // Carrega polígono existente
        loadWkt(textarea.value.trim());

        // Impede o clique no mapa de disparar o submit (só por segurança)
        document.getElementById('map').addEventListener('click', function(e) {
            e.stopPropagation();
        });
    }
});