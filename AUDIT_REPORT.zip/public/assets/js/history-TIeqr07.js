/**
 * history.js — Módulo para a página de histórico de rota
 * Responsável por gráficos, mapa, heatmap interativo e formatação de datas.
 */
(function () {
  'use strict';

  // ─── Inicialização ───────────────────────────────────────────────
  document.addEventListener('DOMContentLoaded', function () {
    const dataEl = document.getElementById('js-data');
    if (!dataEl) {
      console.warn('[History] Elemento #js-data não encontrado. Abortando.');
      return;
    }

    const ds = dataEl.dataset;
    let raw, routeLine, jamLevel, fromName, toName, byJam, hourly, jamColors;

    try {
      raw       = JSON.parse(ds.history);
      routeLine = JSON.parse(ds.line);
      jamLevel  = parseInt(ds.jamLevel, 10) || 0;
      fromName  = JSON.parse(ds.from);
      toName    = JSON.parse(ds.to);
      byJam     = JSON.parse(ds.byJam);
      hourly    = JSON.parse(ds.hourly);
      jamColors = JSON.parse(ds.jamColors);
    } catch (e) {
      console.error('[History] Erro ao parsear dados JSON:', e);
      return;
    }

    const jamLabels = ['Livre', 'Lento', 'Moderado', 'Pesado', 'Muito Pesado', 'Parado'];
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
    const FMT = new Intl.DateTimeFormat('pt-BR', {
      timeZone: tz,
      day: '2-digit',
      month: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    });

    // ─── Gráfico de evolução temporal ─────────────────────────────
    const elHistory = document.getElementById('chart-history');
    if (elHistory && raw.length > 0) {
      const ordered = raw.slice().reverse();
      const labels = ordered.map(r => FMT.format(new Date(r.t)));
      const times = ordered.map(r => r.time !== null ? +(r.time / 60).toFixed(1) : null);
      const hists = ordered.map(r => r.hist !== null ? +(r.hist / 60).toFixed(1) : null);

      const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
      const gridColor = isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.06)';
      const textColor = isDark ? '#b0b0b0' : '#5a5a5a';

      new Chart(elHistory, {
        type: 'line',
        data: {
          labels: labels,
          datasets: [
            {
              label: 'Tempo atual (min)',
              data: times,
              borderColor: '#a12c7b',
              backgroundColor: 'oklch(0.5 0.2 330 / 0.08)',
              tension: 0.3,
              fill: true,
              pointRadius: 2,
              pointHoverRadius: 5,
              spanGaps: true,
            },
            {
              label: 'Histórico (min)',
              data: hists,
              borderColor: '#437a22',
              borderDash: [4, 3],
              tension: 0.3,
              pointRadius: 2,
              pointHoverRadius: 5,
              spanGaps: true,
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          interaction: { mode: 'index', intersect: false },
          plugins: {
            legend: {
              position: 'top',
              labels: {
                color: textColor,
                font: { size: 11 },
                boxWidth: 12,
              },
            },
            tooltip: {
              callbacks: {
                label: ctx => ctx.dataset.label + ': ' + (ctx.parsed.y !== null ? ctx.parsed.y.toFixed(1) + ' min' : '—'),
              },
            },
          },
          scales: {
            x: {
              ticks: { color: textColor, font: { size: 10 }, maxTicksLimit: 12, maxRotation: 45 },
              grid: { color: gridColor },
            },
            y: {
              beginAtZero: true,
              title: { display: true, text: 'minutos', color: textColor },
              ticks: { color: textColor, font: { size: 10 }, callback: v => v + ' min' },
              grid: { color: gridColor },
            },
          },
        },
      });
    }

    // ─── Gráfico de distribuição (doughnut) ────────────────────────
    const elByJam = document.getElementById('chart-byjam');
    if (elByJam && byJam.length > 0) {
      new Chart(elByJam, {
        type: 'doughnut',
        data: {
          labels: jamLabels,
          datasets: [{ data: byJam, backgroundColor: jamColors, borderWidth: 0 }],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: 'right',
              labels: { boxWidth: 12, font: { size: 10 } },
            },
          },
          cutout: '60%',
        },
      });
    }

    // ─── Gráfico de perfil horário (barras) ────────────────────────
    const elHourly = document.getElementById('chart-hourly');
    if (elHourly && hourly.length > 0) {
      new Chart(elHourly, {
        type: 'bar',
        data: {
          labels: hourly.map(h => String(h.bucket).padStart(2, '0') + 'h'),
          datasets: [
            {
              label: 'Tempo atual (min)',
              data: hourly.map(h => h.avgTimeMin),
              backgroundColor: '#a12c7b',
              borderRadius: 3,
            },
            {
              label: 'Histórico (min)',
              data: hourly.map(h => h.avgHistMin),
              backgroundColor: '#437a22',
              borderRadius: 3,
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: 'top',
              labels: { font: { size: 10 }, boxWidth: 12 },
            },
          },
          scales: {
            y: {
              beginAtZero: true,
              title: { display: true, text: 'minutos' },
              ticks: { font: { size: 10 } },
            },
            x: {
              ticks: { font: { size: 9 }, maxRotation: 45 },
            },
          },
        },
      });
    }

    // ─── Mapa Leaflet ──────────────────────────────────────────────
    const mapEl = document.getElementById('history-map');
    if (mapEl && routeLine && routeLine.length >= 2) {
      const map = L.map('history-map', { zoomControl: true, scrollWheelZoom: false });
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors',
        maxZoom: 19,
      }).addTo(map);

      const color = jamColors[jamLevel] || '#888';
      const latlngs = routeLine.map(p => [p.y, p.x]);
      const poly = L.polyline(latlngs, { color: color, weight: 5, opacity: 0.85 }).addTo(map);

      if (latlngs.length >= 2) {
        const mkPin = (letter, bg) => {
          const w = 28,
            h = 36;
          const svg =
            `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 28 36">
              <path d="M14 0 C6.268 0 0 6.268 0 14 C0 22 14 36 14 36 C14 36 28 22 28 14 C28 6.268 21.732 0 14 0 Z"
                    fill="${bg}" stroke="rgba(0,0,0,0.25)" stroke-width="1"/>
              <text x="14" y="19" text-anchor="middle" dominant-baseline="middle"
                    font-family="system-ui,sans-serif" font-size="13" font-weight="700" fill="#fff">${letter}</text>
            </svg>`;
          return L.divIcon({
            html: svg,
            className: '',
            iconSize: [w, h],
            iconAnchor: [w / 2, h],
            popupAnchor: [0, -h],
          });
        };

        L.marker(latlngs[0], { icon: mkPin('A', '#01696f') })
          .bindTooltip(fromName, { permanent: false, direction: 'top' })
          .addTo(map);

        L.marker(latlngs[latlngs.length - 1], { icon: mkPin('B', '#a12c7b') })
          .bindTooltip(toName, { permanent: false, direction: 'top' })
          .addTo(map);
      }

      map.fitBounds(poly.getBounds(), { padding: [28, 28] });
    } else if (mapEl) {
      mapEl.innerHTML =
        '<div style="display:flex;align-items:center;justify-content:center;height:100%;color:var(--color-text-muted);font-size:var(--text-sm)">Geometria da rota não disponível</div>';
    }

    // ─── Formatação das datas no DOM ──────────────────────────────
    document.querySelectorAll('time[data-utc][data-fmt="datetime"]').forEach(el => {
      try {
        const d = new Date(el.dataset.utc);
        if (!isNaN(d.getTime())) {
          el.textContent = FMT.format(d);
        }
      } catch (e) {
        // mantém o conteúdo original
      }
    });

    // ─── Interação com o heatmap (tooltip nativo) ─────────────────
    document.querySelectorAll('.heatmap-data:not(.is-empty)').forEach(cell => {
      cell.addEventListener('click', function () {
        // Pequeno feedback: pisca a célula
        this.style.transition = 'transform 0.1s ease';
        this.style.transform = 'scale(0.95)';
        setTimeout(() => {
          this.style.transform = 'scale(1)';
        }, 100);
      });
    });

    // ─── Ajuste de tema escuro para o Leaflet ─────────────────────
    const observer = new MutationObserver(() => {
      const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
      // Leaflet tiles já são OSM, mas podemos mudar o estilo do controle se quisermos.
      // Não há muito o que fazer com os tiles, mas podemos deixar.
    });
    observer.observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });

    console.log('[History] Página inicializada com sucesso.');
  });
})();
