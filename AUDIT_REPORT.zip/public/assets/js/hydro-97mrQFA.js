// ============================================================
// HIDROLÓGICO - SCRIPT AO VIVO
// ============================================================

(function() {
  'use strict';

  const INTERVAL = 60000; // 60 segundos
  let timer = null;

  // --- Elementos DOM ---
  const tbody = document.getElementById('hydro-tbody');
  const lastEl = document.getElementById('last-update');
  const btnRef = document.getElementById('btn-refresh');
  const refreshIcon = document.getElementById('refresh-icon');
  const totalEl = document.getElementById('total-count');

  // --- Meta dados por nível ---
  const META = {
    normal:          { icon: '✅', rowCss: '',                    barCss: 'bar-normal',  kpiId: 'cnt-normal' },
    atencao:         { icon: '⚠️', rowCss: 'row-atencao',         barCss: 'bar-atencao', kpiId: 'cnt-atencao' },
    alerta:          { icon: '🚨', rowCss: 'row-alerta',          barCss: 'bar-alerta',  kpiId: 'cnt-alerta' },
    transbordamento: { icon: '🌊', rowCss: 'row-transbordamento', barCss: 'bar-transb',  kpiId: 'cnt-transb' },
  };

  // --- Utilitários ---
  function fmt(v) {
    if (v === null || v === undefined) return '—';
    return parseFloat(v).toLocaleString('pt-BR', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }) + ' m';
  }

  function fmtDt(s) {
    if (!s) return '—';
    try {
      const d = new Date(s + 'Z');
      return d.toLocaleString('pt-BR');
    } catch (_) {
      return s;
    }
  }

  function pct(level, transb) {
    if (!transb || transb <= 0 || level === null || level === undefined) return 0;
    return Math.min(Math.round((level / transb) * 100), 100);
  }

  // --- Atualizar KPIs ---
  function updateKPIs(rows) {
    const counts = { normal: 0, atencao: 0, alerta: 0, transbordamento: 0 };
    rows.forEach(r => {
      const k = r.alert_level ?? 'normal';
      if (counts[k] !== undefined) counts[k]++;
      else counts.normal++;
    });

    document.getElementById('cnt-normal').textContent  = counts.normal;
    document.getElementById('cnt-atencao').textContent = counts.atencao;
    document.getElementById('cnt-alerta').textContent  = counts.alerta;
    document.getElementById('cnt-transb').textContent  = counts.transbordamento;
    if (totalEl) totalEl.textContent = rows.length + ' estações';
  }

  // --- Renderizar linhas da tabela ---
  function renderRows(rows) {
    console.log('[HydroLive] renderRows recebeu', rows.length, 'linhas.');

    if (!rows.length) {
      tbody.innerHTML = `
        <tr>
          <td colspan="8">
            <div class="hydro-empty">
              <div class="hydro-empty-icon">💧</div>
              <h3>Sem dados hidrológicos</h3>
              <p>Aguardando primeira leitura.</p>
            </div>
          </td>
        </tr>
      `;
      return;
    }

    updateKPIs(rows);

    let html = '';
    rows.forEach(r => {
      const m = META[r.alert_level ?? 'normal'] || META.normal;
      const p = pct(r.water_level, r.cota_transbordamento);
      const bar = p > 0
        ? `<div class="level-bar-wrap"><div class="level-bar ${m.barCss}" style="width:${p}%"></div></div>`
        : '';

      // Mini gráfico de barras horizontais (nível vs cota de transbordamento)
      let chartHtml = '';
      if (r.cota_transbordamento && r.water_level !== null && r.water_level !== undefined) {
        const pctChart = Math.min((r.water_level / r.cota_transbordamento) * 100, 100);
        chartHtml = `
          <div class="hydro-chart-row">
            <span style="font-size:0.7rem;color:var(--color-text-muted);min-width:36px;">${pctChart.toFixed(0)}%</span>
            <div class="hydro-chart-bar">
              <div class="hydro-chart-fill" style="width:${pctChart}%;background:${r.alert_level === 'transbordamento' ? '#dc2626' : r.alert_level === 'alerta' ? '#f59e0b' : r.alert_level === 'atencao' ? '#eab308' : '#16a34a'};"></div>
              <div class="hydro-chart-marker" style="left:100%;"></div>
            </div>
          </div>
        `;
      }

      html += `
        <tr class="${m.rowCss}">
          <td><span class="level-icon" title="${r.alert_level || 'normal'}">${m.icon}</span></td>
          <td>
            <div style="font-weight:600;">${r.station_name}</div>
            <div style="font-size:0.75rem;color:var(--color-text-muted);">${r.station_code}</div>
          </td>
          <td style="white-space:nowrap;">${r.municipality} / ${r.state}</td>
          <td style="text-align:right;">
            <div style="font-weight:700;font-variant-numeric:tabular-nums;">${fmt(r.water_level)}</div>
            ${bar}
            ${chartHtml}
          </td>
          <td style="text-align:right;font-variant-numeric:tabular-nums;">${fmt(r.cota_atencao)}</td>
          <td style="text-align:right;font-variant-numeric:tabular-nums;">${fmt(r.cota_alerta)}</td>
          <td style="text-align:right;font-variant-numeric:tabular-nums;">${fmt(r.cota_transbordamento)}</td>
          <td style="white-space:nowrap;font-size:0.8rem;">${fmtDt(r.measured_at)}</td>
        </tr>
      `;
    });

    tbody.innerHTML = html;
    if (lastEl) lastEl.textContent = new Date().toLocaleTimeString('pt-BR');
    console.log('[HydroLive] Tabela atualizada.');
  }

  // --- Carregar dados ---
  function load() {
    console.log('[HydroLive] load() chamado.');
    if (btnRef) {
      btnRef.disabled = true;
      if (refreshIcon) refreshIcon.classList.add('spinning');
    }

    const url = document.querySelector('meta[name="hydro-data-url"]')?.content || '/hidrologico/live/data';

    fetch(url, { headers: { 'Accept': 'application/json' } })
      .then(response => {
        if (!response.ok) throw new Error('HTTP ' + response.status);
        return response.json();
      })
      .then(data => renderRows(data))
      .catch(err => console.error('[HydroLive] Erro no fetch:', err))
      .finally(() => {
        if (btnRef) {
          btnRef.disabled = false;
          if (refreshIcon) refreshIcon.classList.remove('spinning');
        }
      });
  }

  // --- Inicialização ---
  function init() {
    console.log('[HydroLive] Inicializando...');

    // Verifica elementos essenciais
    if (!tbody) {
      console.error('[HydroLive] Tbody não encontrado.');
      return;
    }

    // Configura botão de refresh
    if (btnRef) {
      btnRef.addEventListener('click', load);
    }

    // Carrega dados iniciais
    load();

    // Intervalo automático
    if (timer) clearInterval(timer);
    timer = setInterval(load, INTERVAL);
    console.log('[HydroLive] Intervalo configurado para', INTERVAL, 'ms.');

    // Inicializa ícones Lucide (se disponível)
    if (typeof lucide !== 'undefined' && typeof lucide.createIcons === 'function') {
      lucide.createIcons();
    }
  }

  // --- Iniciar após DOM pronto ---
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
