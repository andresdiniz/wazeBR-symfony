// public/js/admin.js – Funcionalidades comuns do admin

document.addEventListener('DOMContentLoaded', () => {

    // ── Toggle de visualização de senha ──
    document.querySelectorAll('.toggle-pw').forEach(btn => {
        btn.addEventListener('click', () => {
            const input = document.getElementById(btn.dataset.target);
            if (input) {
                input.type = input.type === 'password' ? 'text' : 'password';
            }
        });
    });

    // ── Confirmação para ações destrutivas ──
    document.querySelectorAll('[data-confirm]').forEach(el => {
        el.addEventListener('click', (e) => {
            if (!confirm(el.dataset.confirm || 'Tem certeza?')) {
                e.preventDefault();
            }
        });
    });

    // ── Auto-slug (se houver campos name e slug) ──
    const nameInput = document.getElementById('name');
    const slugInput = document.getElementById('slug');
    if (nameInput && slugInput) {
        nameInput.addEventListener('input', () => {
            if (slugInput.dataset.edited) return;
            slugInput.value = nameInput.value
                .toLowerCase()
                .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
                .replace(/[^a-z0-9]+/g, '-')
                .replace(/^-+|-+$/g, '');
        });
        slugInput.addEventListener('input', () => { slugInput.dataset.edited = '1'; });
    }

});