/**
 * history.js — Módulo premium para histórico de rota
 * Gráficos, mapa, heatmap, animações e interatividade
 */
(function () {
  'use strict';

  // ─── Inicialização ───────────────────────────────────────────────
  document.addEventListener('DOMContentLoaded', function () {
    console.log('[History] Inicializando módulo premium...');

    const dataEl = document.getElementById('js-data');
    if (!dataEl) {
      console.warn('[History] Elemento #js-data não encontrado.');
      return;
    }

    const ds = dataEl.dataset;
    let raw, routeLine, jamLevel, fromName, toName, byJam, hourly, jamColors;

    try {
      raw       = JSON.parse(ds.history);
      routeLine = JSON.parse(ds.line);
      jamLevel  = parseInt(ds.jamLevel, 10) || 0;
      fromName  = JSON.parse(ds.from);
      toName    = JSON.parse(ds.to);
      byJam     = JSON.parse(ds.byJam);
      hourly    = JSON.parse(ds.hourly);
      jamColors = JSON.parse(ds.jamColors);
    } catch (e) {
      console.error('[History] Erro ao parsear JSON:', e);
      return;
    }

    const jamLabels = ['Livre', 'Lento', 'Moderado', 'Pesado', 'Muito Pesado', 'Parado'];
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
    const FMT = new Intl.DateTimeFormat('pt-BR', {
      timeZone: tz,
      day: '2-digit',
      month: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    });

    // ─── Helper: tema escuro ──────────────────────────────────────
    function isDark() {
      return document.documentElement.getAttribute('data-theme') === 'dark';
    }

    function getChartColors() {
      const dark = isDark();
      return {
        grid: dark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.06)',
        text: dark ? '#b0b0b0' : '#5a5a5a',
        border: dark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.08)',
      };
    }

    // ─── Gráfico de evolução temporal ─────────────────────────────
    const elHistory = document.getElementById('chart-history');
    if (elHistory && raw.length > 0) {
      const ordered = raw.slice().reverse();
      const labels = ordered.map(r => FMT.format(new Date(r.t)));
      const times = ordered.map(r => r.time !== null ? +(r.time / 60).toFixed(1) : null);
      const hists = ordered.map(r => r.hist !== null ? +(r.hist / 60).toFixed(1) : null);

      const colors = getChartColors();
      new Chart(elHistory, {
        type: 'line',
        data: {
          labels: labels,
          datasets: [
            {
              label: 'Tempo atual (min)',
              data: times,
              borderColor: '#a12c7b',
              backgroundColor: 'oklch(0.5 0.2 330 / 0.08)',
              tension: 0.35,
              fill: true,
              pointRadius: 3,
              pointHoverRadius: 7,
              pointBackgroundColor: '#a12c7b',
              spanGaps: true,
              borderWidth: 2.5,
            },
            {
              label: 'Histórico (min)',
              data: hists,
              borderColor: '#437a22',
              backgroundColor: 'oklch(0.4 0.15 120 / 0.05)',
              borderDash: [5, 4],
              tension: 0.35,
              fill: false,
              pointRadius: 3,
              pointHoverRadius: 7,
              pointBackgroundColor: '#437a22',
              spanGaps: true,
              borderWidth: 2,
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          interaction: { mode: 'index', intersect: false },
          plugins: {
            legend: {
              position: 'top',
              labels: {
                color: colors.text,
                font: { size: 12, weight: '600' },
                boxWidth: 14,
                padding: 16,
              },
            },
            tooltip: {
              backgroundColor: isDark() ? 'rgba(26,32,44,0.9)' : 'rgba(255,255,255,0.95)',
              titleColor: isDark() ? '#f1f5f9' : '#0f172a',
              bodyColor: isDark() ? '#94a3b8' : '#64748b',
              borderColor: colors.border,
              borderWidth: 1,
              cornerRadius: 8,
              boxShadow: '0 8px 24px rgba(0,0,0,0.15)',
              callbacks: {
                label: ctx => ctx.dataset.label + ': ' + (ctx.parsed.y !== null ? ctx.parsed.y.toFixed(1) + ' min' : '—'),
              },
            },
          },
          scales: {
            x: {
              ticks: { color: colors.text, font: { size: 10 }, maxTicksLimit: 14, maxRotation: 45 },
              grid: { color: colors.grid, drawBorder: false },
            },
            y: {
              beginAtZero: true,
              title: { display: true, text: 'minutos', color: colors.text, font: { size: 11 } },
              ticks: { color: colors.text, font: { size: 10 }, callback: v => v + ' min' },
              grid: { color: colors.grid, drawBorder: false },
            },
          },
        },
      });
    }

    // ─── Gráfico de distribuição (doughnut) ────────────────────────
    const elByJam = document.getElementById('chart-byjam');
    if (elByJam && byJam.length > 0) {
      new Chart(elByJam, {
        type: 'doughnut',
        data: {
          labels: jamLabels,
          datasets: [{ data: byJam, backgroundColor: jamColors, borderWidth: 0 }],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          cutout: '65%',
          plugins: {
            legend: {
              position: 'right',
              labels: {
                boxWidth: 14,
                font: { size: 11, weight: '500' },
                color: isDark() ? '#94a3b8' : '#64748b',
                padding: 12,
              },
            },
            tooltip: {
              callbacks: {
                label: ctx => ctx.label + ': ' + ctx.parsed + ' registros',
              },
            },
          },
        },
      });
    }

    // ─── Gráfico de perfil horário (barras) ────────────────────────
    const elHourly = document.getElementById('chart-hourly');
    if (elHourly && hourly.length > 0) {
      const colors = getChartColors();
      new Chart(elHourly, {
        type: 'bar',
        data: {
          labels: hourly.map(h => String(h.bucket).padStart(2, '0') + 'h'),
          datasets: [
            {
              label: 'Tempo atual (min)',
              data: hourly.map(h => h.avgTimeMin),
              backgroundColor: '#a12c7b',
              borderRadius: 4,
              borderSkipped: false,
            },
            {
              label: 'Histórico (min)',
              data: hourly.map(h => h.avgHistMin),
              backgroundColor: '#437a22',
              borderRadius: 4,
              borderSkipped: false,
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: 'top',
              labels: {
                font: { size: 11, weight: '600' },
                boxWidth: 14,
                color: colors.text,
                padding: 12,
              },
            },
            tooltip: {
              callbacks: {
                label: ctx => ctx.dataset.label + ': ' + (ctx.parsed.y !== null ? ctx.parsed.y.toFixed(1) + ' min' : '—'),
              },
            },
          },
          scales: {
            y: {
              beginAtZero: true,
              title: { display: true, text: 'minutos', color: colors.text, font: { size: 10 } },
              ticks: { color: colors.text, font: { size: 9 } },
              grid: { color: colors.grid, drawBorder: false },
            },
            x: {
              ticks: { color: colors.text, font: { size: 9 }, maxRotation: 45 },
              grid: { display: false },
            },
          },
        },
      });
    }

    // ─── Mapa Leaflet ──────────────────────────────────────────────
    // ─── Mapa Leaflet ──────────────────────────────────────────────
const mapEl = document.getElementById('history-map');
if (mapEl && routeLine && routeLine.length >= 2) {
  const map = L.map('history-map', { zoomControl: true, scrollWheelZoom: false });
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap contributors',
    maxZoom: 19,
    crossOrigin: true, // ← resolve problema de CORS/bloqueio
  }).addTo(map);

  // ... resto do código do mapa (cores, polylines, marcadores) ...
}

    // ─── Formatação das datas ──────────────────────────────────────
    document.querySelectorAll('time[data-utc][data-fmt="datetime"]').forEach(el => {
      try {
        const d = new Date(el.dataset.utc);
        if (!isNaN(d.getTime())) {
          el.textContent = FMT.format(d);
        }
      } catch (e) { /* mantém original */ }
    });

    // ─── Interação com heatmap ─────────────────────────────────────
    document.querySelectorAll('.heatmap-data:not(.is-empty)').forEach(cell => {
      cell.addEventListener('click', function () {
        this.style.transform = 'scale(0.92)';
        setTimeout(() => { this.style.transform = 'scale(1)'; }, 150);
      });
      cell.addEventListener('mouseenter', function () {
        this.style.zIndex = '3';
      });
      cell.addEventListener('mouseleave', function () {
        this.style.zIndex = 'auto';
      });
    });

    // ─── Observador de tema para gráficos ─────────────────────────
    const themeObserver = new MutationObserver(() => {
      // Re-renderiza os gráficos? (simplificado: recarregar a página)
      // Para uma solução mais elegante, poderíamos atualizar as cores dos gráficos existentes.
      // Por simplicidade, recarregamos apenas se o usuário mudar o tema.
      // Mas como é uma página estática, não faremos nada agora.
    });
    themeObserver.observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });

    // ─── Inicializar ícones (fallback) ────────────────────────────
    function initLucide() {
      if (typeof lucide !== 'undefined' && typeof lucide.createIcons === 'function') {
        lucide.createIcons();
        console.log('[History] Ícones Lucide inicializados.');
      } else {
        setTimeout(initLucide, 500);
      }
    }
    setTimeout(initLucide, 300);

    console.log('[History] Módulo premium inicializado com sucesso.');
  });
})();
