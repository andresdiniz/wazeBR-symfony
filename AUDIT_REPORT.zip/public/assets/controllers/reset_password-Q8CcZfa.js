// assets/controllers/reset_password.js

document.addEventListener('DOMContentLoaded', function() {
    // ---------- Toggle de senha (Mostrar/Ocultar) ----------
    document.querySelectorAll('[data-password-toggle]').forEach(function(btn) {
        btn.addEventListener('click', function() {
            const wrapper = this.closest('.auth-password');
            const input = wrapper.querySelector('input');
            const isPassword = input.type === 'password';

            input.type = isPassword ? 'text' : 'password';
            this.textContent = isPassword ? 'Ocultar' : 'Mostrar';
            this.setAttribute('aria-pressed', isPassword ? 'true' : 'false');
        });
    });

    // ---------- Referências dos campos ----------
    const passwordInput = document.querySelector('#reset_password_plainPassword');
    const confirmInput = document.querySelector('#reset_password_confirmPassword');
    const strengthIndicator = document.getElementById('password-strength');
    const confirmErrorContainer = document.getElementById('confirm-password-error');

    // ---------- Indicador de força da senha ----------
    if (passwordInput && strengthIndicator) {
        passwordInput.addEventListener('input', function() {
            const value = this.value;
            let strength = 0;

            if (value.length >= 8) strength++;
            if (/[a-z]/.test(value)) strength++;
            if (/[A-Z]/.test(value)) strength++;
            if (/[0-9]/.test(value)) strength++;
            if (/[^a-zA-Z0-9]/.test(value)) strength++;

            const levels = ['Muito fraca', 'Fraca', 'Média', 'Forte', 'Muito forte'];
            const colors = ['#dc2626', '#f59e0b', '#eab308', '#22c55e', '#16a34a'];
            const level = Math.min(strength, 4);

            strengthIndicator.textContent = 'Força: ' + levels[level];
            strengthIndicator.style.color = colors[level];
        });
    }

    // ---------- Impedir copiar/colar no campo de confirmação ----------
    if (confirmInput) {
        // Bloqueia colagem
        confirmInput.addEventListener('paste', function(e) {
            e.preventDefault();
            this.style.borderColor = '#dc2626';
            setTimeout(() => { this.style.borderColor = ''; }, 1000);
        });

        // Bloqueia copiar (tanto do campo quanto do contexto)
        confirmInput.addEventListener('copy', function(e) {
            e.preventDefault();
        });

        // Bloqueia recortar
        confirmInput.addEventListener('cut', function(e) {
            e.preventDefault();
        });

        // Opcional: também bloqueia arrastar texto para dentro
        confirmInput.addEventListener('drop', function(e) {
            e.preventDefault();
        });
    }

    // ---------- Validação em tempo real: senhas coincidem ----------
    function validatePasswordMatch() {
        if (!passwordInput || !confirmInput) return;

        const password = passwordInput.value;
        const confirm = confirmInput.value;

        // Só valida se ambos tiverem conteúdo
        if (password.length > 0 && confirm.length > 0) {
            if (password === confirm) {
                confirmInput.style.borderColor = '#16a34a';
                confirmInput.style.boxShadow = '0 0 0 3px rgba(22, 163, 74, 0.15)';
                if (confirmErrorContainer) {
                    confirmErrorContainer.textContent = '✓ Senhas coincidem';
                    confirmErrorContainer.style.color = '#16a34a';
                }
            } else {
                confirmInput.style.borderColor = '#dc2626';
                confirmInput.style.boxShadow = '0 0 0 3px rgba(220, 38, 38, 0.15)';
                if (confirmErrorContainer) {
                    confirmErrorContainer.textContent = '✗ As senhas não coincidem';
                    confirmErrorContainer.style.color = '#dc2626';
                }
            }
        } else {
            // Se algum campo estiver vazio, reseta o estilo
            confirmInput.style.borderColor = '';
            confirmInput.style.boxShadow = '';
            if (confirmErrorContainer) {
                confirmErrorContainer.textContent = '';
            }
        }
    }

    // Dispara a validação ao digitar em qualquer um dos campos
    if (passwordInput && confirmInput) {
        passwordInput.addEventListener('input', validatePasswordMatch);
        confirmInput.addEventListener('input', validatePasswordMatch);
    }
});