// assets/controllers/reset_password.js

document.addEventListener('DOMContentLoaded', function() {
    // Toggle de senha
    document.querySelectorAll('[data-password-toggle]').forEach(function(btn) {
        btn.addEventListener('click', function() {
            const wrapper = this.closest('.auth-password');
            const input = wrapper.querySelector('input');
            const isPassword = input.type === 'password';

            input.type = isPassword ? 'text' : 'password';
            this.textContent = isPassword ? 'Ocultar' : 'Mostrar';
            this.setAttribute('aria-pressed', isPassword ? 'true' : 'false');
        });
    });

    // Indicador de força
    const passwordInput = document.querySelector('#reset_password_plainPassword');
    const strengthIndicator = document.getElementById('password-strength');

    if (passwordInput && strengthIndicator) {
        passwordInput.addEventListener('input', function() {
            const value = this.value;
            let strength = 0;

            if (value.length >= 8) strength++;
            if (/[a-z]/.test(value)) strength++;
            if (/[A-Z]/.test(value)) strength++;
            if (/[0-9]/.test(value)) strength++;
            if (/[^a-zA-Z0-9]/.test(value)) strength++;

            const levels = ['Muito fraca', 'Fraca', 'Média', 'Forte', 'Muito forte'];
            const colors = ['#dc2626', '#f59e0b', '#eab308', '#22c55e', '#16a34a'];
            const level = Math.min(strength, 4);

            strengthIndicator.textContent = 'Força: ' + levels[level];
            strengthIndicator.style.color = colors[level];
        });
    }
});