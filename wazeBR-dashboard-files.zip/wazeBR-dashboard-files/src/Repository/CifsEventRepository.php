<?php

declare(strict_types=1);

namespace App\Repository;

use App\Entity\CifsEvent;
use App\Entity\Partner;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<CifsEvent>
 */
class CifsEventRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, CifsEvent::class);
    }

    // ── Listagem filtrada (usada pelo CifsEventController) ────────────────────

    /**
     * Lista eventos com filtros opcionais.
     *
     * @param bool         $onlyActive  Se true, retorna apenas eventos ativos (active=true e dentro do período).
     * @param int          $limit       Número máximo de resultados.
     * @param Partner|null $partner     Filtra por parceiro (null = todos).
     * @return CifsEvent[]
     */
    public function findFiltered(
        bool     $onlyActive = false,
        int      $limit      = 50,
        ?Partner $partner    = null,
    ): array {
        $now = new \DateTimeImmutable();
        $qb  = $this->createQueryBuilder('e')
            ->orderBy('e.startTime', 'DESC')
            ->setMaxResults($limit);

        if ($onlyActive) {
            $qb->andWhere('e.active = true')
               ->andWhere('e.startTime <= :now')
               ->andWhere('e.endTime IS NULL OR e.endTime > :now')
               ->setParameter('now', $now);
        }

        if ($partner !== null) {
            $qb->andWhere('e.partner = :partner')
               ->setParameter('partner', $partner);
        }

        return $qb->getQuery()->getResult();
    }

    // ── KPIs ──────────────────────────────────────────────────────────────────

    /**
     * Eventos ativos agora (active=true, startTime <= NOW, endTime > NOW ou sem endTime).
     */
    public function findActiveByPartner(Partner $partner): array
    {
        $now = new \DateTimeImmutable();

        return $this->createQueryBuilder('e')
            ->where('e.partner = :partner')
            ->andWhere('e.active = true')
            ->andWhere('e.startTime <= :now')
            ->andWhere('e.endTime IS NULL OR e.endTime > :now')
            ->setParameter('partner', $partner)
            ->setParameter('now', $now)
            ->orderBy('e.startTime', 'DESC')
            ->getQuery()->getResult();
    }

    /**
     * Eventos programados para os próximos $days dias (não iniciados ainda).
     */
    public function findUpcomingByPartner(Partner $partner, int $days = 7): array
    {
        $now    = new \DateTimeImmutable();
        $future = new \DateTimeImmutable("+{$days} days");

        return $this->createQueryBuilder('e')
            ->where('e.partner = :partner')
            ->andWhere('e.active = true')
            ->andWhere('e.startTime > :now')
            ->andWhere('e.startTime <= :future')
            ->setParameter('partner', $partner)
            ->setParameter('now', $now)
            ->setParameter('future', $future)
            ->orderBy('e.startTime', 'ASC')
            ->getQuery()->getResult();
    }

    /**
     * Contagem de eventos ativos por tipo (CONSTRUCTION, ROAD_CLOSED, etc.).
     * Retorna [['type'=>'CONSTRUCTION','total'=>3], ...]
     */
    public function countActiveByType(Partner $partner): array
    {
        $now = new \DateTimeImmutable();

        $rows = $this->createQueryBuilder('e')
            ->select('e.type AS type, COUNT(e.id) AS total')
            ->where('e.partner = :partner')
            ->andWhere('e.active = true')
            ->andWhere('e.startTime <= :now')
            ->andWhere('e.endTime IS NULL OR e.endTime > :now')
            ->setParameter('partner', $partner)
            ->setParameter('now', $now)
            ->groupBy('e.type')
            ->orderBy('total', 'DESC')
            ->getQuery()->getArrayResult();

        return array_map(static fn($r) => ['type' => $r['type'], 'total' => (int)$r['total']], $rows);
    }

    /**
     * Vias com maior concentração de eventos ativos simultâneos.
     * Retorna [['street'=>'Av. Brasil','total'=>3], ...]
     */
    public function topStreetsByActiveEvents(Partner $partner, int $limit = 10): array
    {
        $now = new \DateTimeImmutable();

        $rows = $this->createQueryBuilder('e')
            ->select('e.street AS street, COUNT(e.id) AS total')
            ->where('e.partner = :partner')
            ->andWhere('e.active = true')
            ->andWhere('e.startTime <= :now')
            ->andWhere('e.endTime IS NULL OR e.endTime > :now')
            ->andWhere('e.street IS NOT NULL')
            ->setParameter('partner', $partner)
            ->setParameter('now', $now)
            ->groupBy('e.street')
            ->orderBy('total', 'DESC')
            ->setMaxResults($limit)
            ->getQuery()->getArrayResult();

        return array_map(static fn($r) => ['street' => $r['street'], 'total' => (int)$r['total']], $rows);
    }

    /**
     * Eventos criados/reportados dentro do período (usa creationTime).
     */
    public function countInPeriod(Partner $partner, \DateTimeInterface $from, \DateTimeInterface $to): int
    {
        return (int) $this->createQueryBuilder('e')
            ->select('COUNT(e.id)')
            ->where('e.partner = :partner')
            ->andWhere('e.creationTime BETWEEN :from AND :to')
            ->setParameter('partner', $partner)
            ->setParameter('from', $from)
            ->setParameter('to', $to)
            ->getQuery()->getSingleScalarResult();
    }

    /**
     * Total de eventos ativos agora.
     */
    public function countActive(Partner $partner): int
    {
        $now = new \DateTimeImmutable();

        return (int) $this->createQueryBuilder('e')
            ->select('COUNT(e.id)')
            ->where('e.partner = :partner')
            ->andWhere('e.active = true')
            ->andWhere('e.startTime <= :now')
            ->andWhere('e.endTime IS NULL OR e.endTime > :now')
            ->setParameter('partner', $partner)
            ->setParameter('now', $now)
            ->getQuery()->getSingleScalarResult();
    }
}
